/**
 * Represents the base class of the rewards program.
 * This is the tier below gold which does not give as many benefits.
 */
 
class DefaultTier implements Tier 
{  
    private int numFlights; 
    private int cancelledFlightCount;
    private int flightDistance;
    
    /**
     * Constructs a new DefaultTier with the given flight distance and cancelled flight count.
     * @param flightDistance 
     * @param cancelledFlightCount 
     */
     
    public DefaultTier(int flightDistance, int cancelledFlightCount) {
        this.flightDistance = flightDistance;
        this.cancelledFlightCount = cancelledFlightCount;
    }
    
    /**
     * Returns a string of  DefaultTier.
     * @return string "Default Tier"
     */
     
    @Override
    public String toString() {
        return "Default Tier";
    }
    
    /**
     * Adds flight to DefaultTier. If flight is cancelled, the cancelled 
     * flight count is incremented and the flight distance is set to 0.
     * @param isCancelled 
     */
     
    @Override
    public void addFlight(boolean isCancelled) {
        if(isCancelled) {
            cancelledFlightCount++;
            flightDistance = cancelledFlightCount * 0; 
        }
        numFlights++;
    }
    
    /**
     * Returns amount of flights taken.
     * @return numFlights
     */
     
    @Override
    public int getFlights() {
        return numFlights;
    }
    
    /**
     * Returns the number of cancelled flights.
     * @return cancelledFlightCount
     */
     
    @Override
    public int getCancelledFlights() {
        return cancelledFlightCount;
    }
    
    /**
     * Returns the total distance traveled in miles.
     * @return flightDistance
     */
     
    @Override
    public int getMiles() {
        return flightDistance;
    }
}
