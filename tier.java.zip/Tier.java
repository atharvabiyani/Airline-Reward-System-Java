/**
 * The Tier interface is a outline for the minimum set of methods that every reward tier class must implement. 
 * It serves as a blueprint for creating the different reward tiers and ensures that they all have a consistent set of behaviors.
 */
 
interface Tier 
{    
    /**
     * Returns a string of this Tier.
     */
     
    String toString();
    
    /**
     * Adds a flight to Tier.
     * @param isCancelled 
     */
     
    void addFlight(boolean isCancelled);
    
    /**
     * Returns the total amount of miles by this Tier.
     */
     
    int getMiles();   
    
    /**
     * Returns number of cancelled flights for Tier.
     */
     
    int getCancelledFlights(); 
    
    /**
     * Returns total number of flights for Tier.
     */
     
    int getFlights();   
}
