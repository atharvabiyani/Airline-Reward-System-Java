/**
 * Gold class implmenets Tier and represents a tier of gold status. 
 */
     
class Gold implements Tier 
{
    private int numFlights;
    private int cancelledFlightCount;
    private int flightDistance;
    
    /**
     * Constructor for Gold class.
     * @param flightDistance 
     * @param cancelledFlightCount
     */
     
    public Gold(int flightDistance, int cancelledFlightCount) {
        this.flightDistance = flightDistance;
        this.cancelledFlightCount = cancelledFlightCount;
    }
    
    /**
     * Returns a string of Gold status.
     * @return "Gold"
     */
     
    @Override
    public String toString() {
        return "Gold";
    }
    
    /**
     * Adds  flight for the gold status passenger/updates flight distance and cancelled flight count if necessary.
     * @param isCancelled 
     */
     
    @Override
    public void addFlight(boolean isCancelled) {
        if(isCancelled) {
            cancelledFlightCount++;
            flightDistance = cancelledFlightCount * 1000; 
        }
        numFlights++;
    }
    
    /**
     * Returns the total number of flights taken by the gold status passenger.
     * @return numFlights
     */
     
    @Override
    public int getFlights() {
        return numFlights;
    }
    
    /**
     * Returns the number of flights cancelled by the gold status passenger.
     * @return cancelledFlightCount
     */
     
    @Override
    public int getCancelledFlights() {
        return cancelledFlightCount;
    }
    
    /**
     * Returns the total flight distance covered by the gold status passenger.
     * @return flightDistance
     */
     
    @Override
    public int getMiles() {
        return flightDistance;
    }
}
