/**
 * A class representing the Platinum Pro status of the rewards program.
 */
 
class PlatinumPro implements Tier 
{
    private int numFlights;
    private int cancelledFlightCount;
    private int flightDistance;
    
    /**
     * Constructs PlatinumPro object with flight distance
     * and cancelled flight count.
     *
     * @param flightDistance
     * @param cancelledFlightCount
     */
     
    public PlatinumPro(int flightDistance, int cancelledFlightCount) {
        this.flightDistance = flightDistance;
        this.cancelledFlightCount = cancelledFlightCount;
    }
    
    /**
     * Returns a string representation of this status.
     *
     * @return "Platinum Pro"
     */
     
    @Override
    public String toString() {
        return "Platinum Pro"; 
    }
    
    /**
     * Updates tier based on new flight.
     * Incrementes number of flights taken and if flight is cancelled, the cancelled flight
     * count and the flight distance are affected .
     *
     * @param isCancelled 
     */
     
    @Override
    public void addFlight(boolean isCancelled) {
        if(isCancelled) {
            cancelledFlightCount++;
            flightDistance = cancelledFlightCount * 2000;
        }
        numFlights++;
    }
    
    /**
     * Returns the total number of flights taken.
     *
     * @return numFlights
     */
     
    @Override
    public int getFlights() {
        return numFlights;
    }
    
    /**
     * Returns the number of flights cancelled.
     *
     * @return cancelledFlightCount
     */
     
    @Override
    public int getCancelledFlights() {
        return cancelledFlightCount;
    }
    
    /**
     * Returns the total distance flown.
     *
     * @return flightDistance
     */
     
    @Override
    public int getMiles() {
        return flightDistance;
    }
}
