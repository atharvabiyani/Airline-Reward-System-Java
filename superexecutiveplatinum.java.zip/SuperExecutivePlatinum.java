/**
 * Represents Super Executive Platinum status in the rewards program.
 * In this tier a passenger earns miles at 2000 miles for each cancelled flight.
 */
 
class SuperExecutivePlatinum implements Tier 
{  
    private int numFlights;
    private int cancelledFlightCount;
    private int flightDistance;
    
    /**
     * Constructs a Super Executive Platinum tier object with flight distance and cancelled flight count.
     *
     * @param flightDistance 
     * @param cancelledFlightCount 
     */
     
    public SuperExecutivePlatinum(int flightDistance, int cancelledFlightCount) {
        this.flightDistance = flightDistance;
        this.cancelledFlightCount = cancelledFlightCount;
    }
    
    /**
     * Returns the name of the tier in the form of a String.
     *
     * @return "SuperExecutivePlatinum"
     */
     
    @Override
    public String toString() {
        return "Super Executive Platinum";
    }
    
    /**
     * Adds a flight to passenger's history/updates cancelled flight count and distance travelled if flight was cancelled.
     *
     * @param isCancelled 
     */
     
    @Override
    public void addFlight(boolean isCancelled) {
        if(isCancelled) {
            cancelledFlightCount++;
            flightDistance = cancelledFlightCount * 2000; 
        }
        numFlights++;
    }
    
    /**
     * Returns total number of flights taken by passenger.
     *
     * @return numFlights
     */
     
    @Override
    public int getFlights() {
        return numFlights;
    }
    
    /**
     * Returns number of flights that were cancelled by passenger.
     *
     * @return cancelledFlightCount
     */
     
    @Override
    public int getCancelledFlights() {
        return cancelledFlightCount;
    }
    
    /**
     * Returns total distance travelled by passenger
     *
     * @return flightDistance
     */
     
    @Override
    public int getMiles() {
        return flightDistance;
    }
}
