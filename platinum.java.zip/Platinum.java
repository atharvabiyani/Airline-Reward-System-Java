/**
 * Platinum class implmenets Tier and represents a tier of platinum status. 
 */
 
class Platinum implements Tier 
{    
    private int numFlights;
    private int cancelledFlightCount;
    private int flightDistance;
    
    /**
     * Constructs a Platinum tier object with flight distance and
     * cancelled flight count.
     * 
     * @param flightDistance 
     * @param cancelledFlightCount
     */
     
    public Platinum(int flightDistance, int cancelledFlightCount) {
        this.flightDistance = flightDistance;
        this.cancelledFlightCount = cancelledFlightCount;
    }
    
    /**
     * Returns a string of Platinum status
     * 
     * @return "Platinum"
     */
     
    @Override
    public String toString() {
        return "Platinum";
    }
    
    /**
     * Adds flight to passenger history. If flight is cancelled, 
     * cancelled flight count is incremented and flight distance is set to 1000 times
     * the number of cancelled flights.
     * 
     * @param isCancelled 
     */
     
    @Override
    public void addFlight(boolean isCancelled) {
        if(isCancelled) {
            cancelledFlightCount++;
            flightDistance = cancelledFlightCount * 1000; 
        }
        numFlights++;
    }
    
    /**
     * Returns the number of flights taken by the passenger.
     * 
     * @return numFlights
     */
 
    @Override
    public int getFlights() {
        return numFlights;
    }
    
    /**
     * Returns the number of flights cancelled by the passenger.
     * 
     * @return cancelledFlightCount
     */
     
    @Override
    public int getCancelledFlights() {
        return cancelledFlightCount;
    }
    
    /**
     * Returns the total distance traveled by the passenger.
     * 
     * @return flightDistance
     */
     
    @Override
    public int getMiles() {
        return flightDistance;
    }
}
