/**
 * This class implements the Tier interface for Executive Platinum status in the rewards program.
 */
 
class ExecutivePlatinum implements Tier 
{   
    private int numFlights;
    private int cancelledFlightCount;
    private int flightDistance;
    
    /**
     * Constructs ExecutivePlatinum object with flightDistance and cancelledFlightCount.
     * 
     * @param flightDistance 
     * @param cancelledFlightCount
     */
     
    public ExecutivePlatinum(int flightDistance, int cancelledFlightCount) {
        this.flightDistance = flightDistance;
        this.cancelledFlightCount = cancelledFlightCount;
    }
    
    /**
     * Returns a String of ExecutivePlatinum status.
     * 
     * @return "ExecutivePlatinum"
     */
     
    @Override
    public String toString() {
        return "Executive Platinum";
    }
    
    /**
     * Adds a flight to passengers history.
     * If flight is cancelled, the cancelledFlightCount and flightDistance are changed accordingly.
     * 
     * @param isCancelled 
     */
     
    @Override
    public void addFlight(boolean isCancelled) {
        if(isCancelled) {
            cancelledFlightCount++;
            flightDistance = cancelledFlightCount * 1000; 
        }
        numFlights++;
    }
    
    /**
     * Returns the number of flights taken by the member.
     * 
     * @return numFlights
     */
     
    @Override
    public int getFlights() {
        return numFlights;
    }
    
    /**
     * Returns the number of flights cancelled by the member.
     * 
     * @return cancelledFlightCount
     */
     
    @Override
    public int getCancelledFlights() {
        return cancelledFlightCount;
    }
    
    /**
     * Returns the total flight distance in miles.
     * 
     * @return flightDistance
     */
     
    @Override
    public int getMiles() {
        return flightDistance;
    }
}