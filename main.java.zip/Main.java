/**
 * This project has a rewards program calculator for NorthEast Airlines, which motivates passengers 
 * to fly with this airlines even after bad incident which hurt the companies reputation. 
 * The program calculates rewards and assigns passengers to either Gold, Platinum, 
 * Platinum Pro, and Executive Platinum or Super Executive Platinum. 
 * 
 * @author Atharva Biyani
 * @version 1.0 
 * @date 04/07/2023
 */

import java.io.*;
import java.util.*;


class Main 
{
    /**
    * The main method will read in the .txt file and processes the passenger information.
    * @throws IOException if an input or output error occurs
    * @param args the command-line arguments
    */
    
    public static void main(String[] args) throws IOException {
        FileInputStream data = null;    // Initialize the variables for input file
        Scanner info = null;  
        data = new FileInputStream("flight-data.txt");  
        info = new Scanner(data);  
    
        ArrayList <Passenger> passengerList = new ArrayList <Passenger>();  // Initialize ArrayList to store passenger objects
    
        String flightCancelled; // Initialize variables for passenger information
        int passengerID;
        String passengerComplaint = "N";
   
        while (info.hasNextLine()) {    // Processing passenger data from input file
            passengerID = info.nextInt();  
            flightCancelled = info.next();  
            if(flightCancelled.equals("Y")) {   // Check if flight is cancelled and update passenger information accordingly
                passengerComplaint = info.next();
            }
            
            boolean entryMet = false;  
            for(int i = 0; i < passengerList.size(); i++) { // Updating passenger information if passenger ID already exists in the ArrayList
                if(passengerList.get(i).ID() == passengerID) {
                    entryMet = true;  
                    if(flightCancelled.equals("Y")) {   // Check if flight is cancelled and add/update passenger's flight status
                        boolean cancel = true; 
                        passengerList.get(i).addFlight(cancel);  
                    }
                    else {
                        boolean stop = false;      
                        passengerList.get(i).addFlight(stop);
                    }
                    if(passengerComplaint.equals("Y")) {    // Check if passenger has complaint and get approval for mileage multiplier
                        boolean multiplier = false;
                        passengerList.get(i).getApprovalForMultiplier(multiplier);
                    }
                }
            }
            
            if(entryMet == false) { // Adding new passenger information if passenger ID does not already exist in the ArrayList
                Passenger passenger = new Passenger(passengerID, new DefaultTier (0,0), 0, 0);  
                passengerList.add(passenger);  
              
                if(flightCancelled.equals("Y")) {   // Check if flight is cancelled and add/update passenger's flight status
                    boolean cancel = true; 
                    passenger.addFlight(cancel);  
                }
                else {
                    boolean stop = false; 
                    passenger.addFlight(stop);
                }
                if(passengerComplaint.equals("Y")) {    // Check if passenger has complaint and get approval for mileage multiplier
                    boolean multiplier = false;
                    passenger.getApprovalForMultiplier(multiplier);
                }
            }
            
            for(int i = 0; i < passengerList.size(); i++) { // Check passenger's cancelled flight status and update tier status
                if(passengerList.get(i).hasMultiplier() && (passengerList.get(i).getCancelledFlights() >= 50 && passengerList.get(i).getCancelledFlights() < 100)) {
                    passengerList.get(i).getPlatinumPro();
                }
                if(passengerList.get(i).hasMultiplier() && (passengerList.get(i).getCancelledFlights() >= 100)) {
                    passengerList.get(i).getSuperExecutivePlatinum();
                }
            }
        }
    
        Main main = new Main();  // Create instance of Main class to call print method
        main.print(passengerList);
        info.close();        
        data.close();
    } 
    
    /**
     * This method prints the passenger information for the given passenger ID.
     * @param passengerList the list of all passengers
     * @throws IOException if an input or output error occurs
    */
  
    public void print(ArrayList<Passenger> passengerList) throws IOException {
        Scanner input = new Scanner(System.in);
        int selectedID = 0;
        while (selectedID != -1) {  // A loop to keep asking for passenger ID until -1 is entered to quit
            System.out.print("\nEnter a Passenger ID or type -1 to quit: ");
            selectedID = input.nextInt();   // Reads input from user for passenger ID
            if (selectedID != -1) {
                boolean passengerFound = false;
                int passengerIndex = -1;
                for (int i = 0; i < passengerList.size(); i++) {    // Loop through the passengerList to find the passenger with given ID
                    if (selectedID == passengerList.get(i).ID()) {  // If the ID matches, set passengerFound to true, store the index and break the loop
                        passengerFound = true;
                        passengerIndex = i;
                        break;
                    }
                }
                if (passengerFound) {   // If passenger is found in the list, print needed passenger information
                    System.out.println("Tier Status: " + passengerList.get(passengerIndex).getTier());
                    System.out.println("Total Miles For Entire Year: " + passengerList.get(passengerIndex).getMiles());
                    System.out.println("Total Flight Cancellations: " + passengerList.get(passengerIndex).getCancelledFlights());
                    System.out.println("Mileage Multiplier? (true=yes, false=no): " + passengerList.get(passengerIndex).hasMultiplier());
                } 
                else {  // If passenger is not found in the list, print an error message
                System.out.println("This Passenger ID is Wrong, Please Try Again");
                }
            }
        }
    }
}
