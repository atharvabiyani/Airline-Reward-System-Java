/**
 * This class represents a passenger and contains information about the passenger's reward tier and flight history.
 * The Passenger class methods access the passenger's current tier, miles earned, number of cancelled flights, and 
 * whether or not the passenger has the mileage multiplier, etc..
 */

class Passenger 
{
    /**
     * The status of the passenger.
     */
     
    private Tier status;
    
    /**
     * Return string representation of the passenger's tier.
     * @return status.toString
     */
     
    public String getTier() {
        return status.toString();
    }
    
    /**
     * Return total miles traveled by the passenger in the current year.
     * @return status.getMiles
     */
     
    public int getMiles() {
        return status.getMiles();
    }
    
    /**
     * Return total number of flight cancellations experienced by the passenger in the current year.
     * @return status.getCancelledFlights
     */
     
    public int getCancelledFlights() {
        return status.getCancelledFlights();
    }
    
    /**
     * Returns tier of the passenger.
     * @return status
     */
     
    public Tier getStatus() {
        return status;
    }
    
    private boolean eligibleForMultiplier;
    
    /**
     * Indicates whether the passenger is eligible for a mileage multiplier.
     * @return true if passenger is eligible for mileage multiplier, else false.
     */
     
    public boolean hasMultiplier() {
        if(status instanceof Gold) {
            return false;
        }
        if(status instanceof DefaultTier) {
            return false;
        }
        return eligibleForMultiplier;
    }
    
    /**
     * Sets the eligibility of the passenger for a mileage multiplier.
     * @param true if passenger is eligible for a mileage multiplier, else false.
     */
     
    public void getApprovalForMultiplier(boolean eligible) {
        eligibleForMultiplier = eligible; 
    }
    
    /**
     * Adds a flight to the passenger's travel history.
     * @param isCancelled true if flight was cancelled, else false.
     */
     
    public void addFlight(boolean isCancelled) {
        status.addFlight(isCancelled);  
        if(status.getCancelledFlights() < 25) {
            status = new DefaultTier(status.getMiles(), status.getCancelledFlights());
        }
        else if(status.getCancelledFlights() >= 25 && status.getCancelledFlights() < 50) {
            status = new Gold(status.getMiles(), status.getCancelledFlights());   
        }
        else if(status.getCancelledFlights() >= 50 && status.getCancelledFlights() < 100) {
            status = new Platinum(status.getMiles(), status.getCancelledFlights());
        }
        else {
            status = new ExecutivePlatinum(status.getMiles(), status.getCancelledFlights());
        }
    }
    
    /**
     * Upgrades the passenger's tier to Platinum Pro.
     */
    
    public void getPlatinumPro() {
        status = new PlatinumPro(status.getMiles(), status.getCancelledFlights());
    }
    
    /**
     * Upgrades the passenger's tier to Super Executive Platinum.
     */
  
    public void getSuperExecutivePlatinum() {
        status = new SuperExecutivePlatinum(status.getMiles(), status.getCancelledFlights());
    }
    
    private int ID;
    
    /**
     * Returns tier of the passenger.
     * @return status
     */
    public int ID() {
        return ID;
    }
    
    /**
     * Returns identifier of passenger.
     * Sets eligibleForMultiplier to true and passes through miles and cancelledFlights.
     * Constructor sets the status and ID.
     * @return identifier of passenger
     */
    
    public Passenger(int ID, Tier status, int miles, int cancelledFlights) {
        this.ID = ID;
        this.status = status;
        this.eligibleForMultiplier = true;
    }
}
